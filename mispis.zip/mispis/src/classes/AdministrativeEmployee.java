package classes;

public class AdministrativeEmployee extends Employee {
}